import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Key, VerificationResponse } from "@shared/schema";

const LINKVERTISE_URLS = {
  step1: "https://linkvertise.com/your-first-step",
  step2: "https://linkvertise.com/your-second-step", 
  step3: "https://linkvertise.com/your-third-step"
};

export default function Home() {
  const [location] = useLocation();
  const [currentStep, setCurrentStep] = useState(1);
  const [testKey, setTestKey] = useState("");
  const [verifyResult, setVerifyResult] = useState<VerificationResponse | null>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Parse URL parameters to determine current step
  useEffect(() => {
    const url = new URL(window.location.href);
    const stepParam = url.searchParams.get("step");
    
    if (stepParam === "1done") {
      setCurrentStep(2);
    } else if (stepParam === "2done") {
      setCurrentStep(3);
    } else if (stepParam === "3done") {
      setCurrentStep(4);
      // Auto-generate key when reaching step 4
      generateKey();
    } else {
      setCurrentStep(1);
    }
  }, [location]);

  // Query current key
  const { data: currentKey, isLoading: keyLoading } = useQuery<Key>({
    queryKey: ["/api/current-key"],
    enabled: currentStep === 4,
    retry: false,
  });

  // Generate key mutation
  const generateKeyMutation = useMutation({
    mutationFn: () => apiRequest("POST", "/api/generate-key"),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/current-key"] });
      toast({
        title: "Key Generated!",
        description: "Your 24-hour access key is ready.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to generate key. Please try again.",
        variant: "destructive",
      });
    },
  });

  const generateKey = () => {
    generateKeyMutation.mutate();
  };

  const handleStepClick = (step: number) => {
    if (step === 1) {
      window.location.href = LINKVERTISE_URLS.step1;
    } else if (step === 2) {
      window.location.href = LINKVERTISE_URLS.step2;
    } else if (step === 3) {
      window.location.href = LINKVERTISE_URLS.step3;
    }
  };

  const copyKey = async (key: string) => {
    try {
      await navigator.clipboard.writeText(key);
      toast({
        title: "Copied!",
        description: "Key copied to clipboard.",
      });
    } catch (error) {
      toast({
        title: "Copy Failed",
        description: "Please copy the key manually.",
        variant: "destructive",
      });
    }
  };

  const verifyKey = async () => {
    if (!testKey.trim()) return;
    
    try {
      const response = await fetch(`/verify?key=${encodeURIComponent(testKey)}`);
      const result = await response.json() as VerificationResponse;
      setVerifyResult(result);
    } catch (error) {
      setVerifyResult({
        status: "invalid",
        message: "Invalid key"
      });
    }
  };

  const formatExpirationTime = (timestamp: number) => {
    const date = new Date(timestamp * 1000);
    return date.toLocaleString("en-US", {
      month: "long",
      day: "numeric", 
      year: "numeric",
      hour: "numeric",
      minute: "2-digit",
      hour12: true
    });
  };

  const getProgressWidth = () => {
    if (currentStep === 1) return "33.33%";
    if (currentStep === 2) return "66.66%";
    return "100%";
  };

  return (
    <div className="bg-gray-50 min-h-screen">
      <div className="container mx-auto px-4 py-8 max-w-md">
        
        {/* Header */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-primary rounded-full mb-4">
            <i className="fas fa-key text-white text-2xl"></i>
          </div>
          <h1 className="text-2xl font-bold text-gray-900 mb-2">24-Hour Key System</h1>
          <p className="text-gray-600 text-sm">Complete all steps to generate your access key</p>
        </div>

        {/* Step 1 */}
        {currentStep === 1 && (
          <Card className="bg-white rounded-lg shadow-md p-6 mb-6">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center space-x-3">
                <div className="flex items-center justify-center w-8 h-8 bg-primary text-white rounded-full text-sm font-semibold">
                  1
                </div>
                <span className="text-lg font-semibold text-gray-900">Step 1 of 3</span>
              </div>
              <div className="text-sm text-gray-500">
                <i className="fas fa-clock mr-1"></i>
                ~30 seconds
              </div>
            </div>

            <div className="w-full bg-gray-200 rounded-full h-2 mb-6">
              <div className="bg-primary h-2 rounded-full transition-all duration-300" style={{width: getProgressWidth()}}></div>
            </div>

            <div className="text-center mb-6">
              <h3 className="text-xl font-semibold text-gray-900 mb-3">Complete First Task</h3>
              <p className="text-gray-600 mb-6">Click the button below to complete the first verification step through Linkvertise.</p>
              
              <Button 
                onClick={() => handleStepClick(1)}
                className="w-full bg-primary hover:bg-blue-800 text-white font-semibold py-4 px-6 rounded-lg transition-colors duration-200 mb-4"
              >
                <i className="fas fa-external-link-alt mr-2"></i>
                Continue to Step 1
              </Button>
              
              <p className="text-xs text-gray-500">
                <i className="fas fa-info-circle mr-1"></i>
                You'll be redirected to complete a short task
              </p>
            </div>
          </Card>
        )}

        {/* Step 2 */}
        {currentStep === 2 && (
          <Card className="bg-white rounded-lg shadow-md p-6 mb-6">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center space-x-3">
                <div className="flex items-center justify-center w-8 h-8 bg-success text-white rounded-full text-sm">
                  <i className="fas fa-check"></i>
                </div>
                <div className="flex items-center justify-center w-8 h-8 bg-primary text-white rounded-full text-sm font-semibold">
                  2
                </div>
                <span className="text-lg font-semibold text-gray-900">Step 2 of 3</span>
              </div>
              <div className="text-sm text-gray-500">
                <i className="fas fa-clock mr-1"></i>
                ~30 seconds
              </div>
            </div>

            <div className="w-full bg-gray-200 rounded-full h-2 mb-6">
              <div className="bg-primary h-2 rounded-full transition-all duration-300" style={{width: getProgressWidth()}}></div>
            </div>

            <div className="text-center mb-6">
              <div className="inline-flex items-center bg-green-50 text-green-800 px-3 py-1 rounded-full text-sm font-medium mb-4">
                <i className="fas fa-check-circle mr-2"></i>
                Step 1 Complete
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">Complete Second Task</h3>
              <p className="text-gray-600 mb-6">Great progress! Now complete the second verification step.</p>
              
              <Button 
                onClick={() => handleStepClick(2)}
                className="w-full bg-primary hover:bg-blue-800 text-white font-semibold py-4 px-6 rounded-lg transition-colors duration-200 mb-4"
              >
                <i className="fas fa-external-link-alt mr-2"></i>
                Continue to Step 2
              </Button>
              
              <p className="text-xs text-gray-500">
                <i className="fas fa-shield-alt mr-1"></i>
                Secure verification process
              </p>
            </div>
          </Card>
        )}

        {/* Step 3 */}
        {currentStep === 3 && (
          <Card className="bg-white rounded-lg shadow-md p-6 mb-6">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center space-x-3">
                <div className="flex items-center justify-center w-8 h-8 bg-success text-white rounded-full text-sm">
                  <i className="fas fa-check"></i>
                </div>
                <div className="flex items-center justify-center w-8 h-8 bg-success text-white rounded-full text-sm">
                  <i className="fas fa-check"></i>
                </div>
                <div className="flex items-center justify-center w-8 h-8 bg-primary text-white rounded-full text-sm font-semibold">
                  3
                </div>
                <span className="text-lg font-semibold text-gray-900">Step 3 of 3</span>
              </div>
              <div className="text-sm text-gray-500">
                <i className="fas fa-clock mr-1"></i>
                ~30 seconds
              </div>
            </div>

            <div className="w-full bg-gray-200 rounded-full h-2 mb-6">
              <div className="bg-primary h-2 rounded-full transition-all duration-300" style={{width: getProgressWidth()}}></div>
            </div>

            <div className="text-center mb-6">
              <div className="inline-flex items-center bg-green-50 text-green-800 px-3 py-1 rounded-full text-sm font-medium mb-4">
                <i className="fas fa-check-circle mr-2"></i>
                2 of 3 Steps Complete
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">Final Step</h3>
              <p className="text-gray-600 mb-6">Almost there! Complete the final verification step to generate your key.</p>
              
              <Button 
                onClick={() => handleStepClick(3)}
                className="w-full bg-primary hover:bg-blue-800 text-white font-semibold py-4 px-6 rounded-lg transition-colors duration-200 mb-4"
              >
                <i className="fas fa-external-link-alt mr-2"></i>
                Complete Final Step
              </Button>
              
              <p className="text-xs text-gray-500">
                <i className="fas fa-star mr-1"></i>
                Your key will be generated after this step
              </p>
            </div>
          </Card>
        )}

        {/* Key Generated */}
        {currentStep === 4 && (
          <Card className="bg-white rounded-lg shadow-md p-6 mb-6">
            <div className="text-center mb-6">
              <div className="inline-flex items-center justify-center w-16 h-16 bg-success rounded-full mb-4 animate-pulse">
                <i className="fas fa-check text-white text-2xl"></i>
              </div>
              <h2 className="text-2xl font-bold text-gray-900 mb-2">Key Generated Successfully!</h2>
              <p className="text-gray-600">Your 24-hour access key is ready. Copy it and keep it safe.</p>
            </div>

            {keyLoading || generateKeyMutation.isPending ? (
              <div className="text-center py-8">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
                <p className="text-gray-600 mt-2">Generating your key...</p>
              </div>
            ) : currentKey ? (
              <div className="bg-gray-50 rounded-lg p-4 mb-6">
                <div className="flex items-center justify-between mb-3">
                  <span className="text-sm font-medium text-gray-700">Your Access Key</span>
                  <div className="flex items-center text-green-600 text-sm">
                    <div className="w-2 h-2 bg-green-600 rounded-full mr-2 animate-pulse"></div>
                    Active
                  </div>
                </div>
                
                <div className="bg-white border-2 border-dashed border-gray-300 rounded-lg p-4 mb-4">
                  <div className="font-mono text-lg font-semibold text-center text-gray-900 tracking-wider select-all">
                    {currentKey.key}
                  </div>
                </div>
                
                <Button 
                  onClick={() => copyKey(currentKey.key)}
                  className="w-full bg-secondary hover:bg-gray-700 text-white font-semibold py-3 px-4 rounded-lg transition-colors duration-200 mb-3"
                >
                  <i className="fas fa-copy mr-2"></i>
                  Copy Key
                </Button>
                
                <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3">
                  <div className="flex items-center text-yellow-800">
                    <i className="fas fa-clock mr-2"></i>
                    <div>
                      <p className="text-sm font-medium">Expires in 24 hours</p>
                      <p className="text-xs">{formatExpirationTime(currentKey.expired)}</p>
                    </div>
                  </div>
                </div>
              </div>
            ) : (
              <div className="text-center py-8">
                <p className="text-gray-600 mb-4">Failed to generate key. Please try again.</p>
                <Button onClick={generateKey} className="bg-primary hover:bg-blue-800 text-white">
                  Retry
                </Button>
              </div>
            )}

            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <h4 className="font-semibold text-blue-900 mb-2">
                <i className="fas fa-info-circle mr-2"></i>
                How to Verify Your Key
              </h4>
              <p className="text-blue-800 text-sm mb-3">Send a GET request to the verification endpoint:</p>
              <div className="bg-blue-100 rounded-lg p-3 font-mono text-sm text-blue-900">
                GET /verify?key=YOUR_KEY
              </div>
            </div>
          </Card>
        )}

        {/* Autoscale API Demo */}
        <Card className="bg-white rounded-lg shadow-md p-6 mb-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">
            <i className="fas fa-rocket mr-2 text-blue-600"></i>
            Autoscale Deployment API
          </h3>
          
          <p className="text-gray-600 text-sm mb-4">For Autoscale deployments, use the persistent /get-key endpoint:</p>
          
          <div className="bg-gray-50 rounded-lg p-4 mb-4">
            <div className="flex items-center justify-between mb-3">
              <span className="text-sm font-medium text-gray-700">Persistent Key Endpoint</span>
              <div className="flex items-center text-blue-600 text-sm">
                <div className="w-2 h-2 bg-blue-600 rounded-full mr-2"></div>
                ReplDB Storage
              </div>
            </div>
            
            <div className="bg-white border border-gray-200 rounded-lg p-3 mb-3">
              <div className="font-mono text-sm text-gray-900">
                GET /get-key
              </div>
            </div>
            
            <div className="text-xs text-gray-600 mb-3">
              <i className="fas fa-info-circle mr-1"></i>
              Returns existing key if valid, generates new one if expired
            </div>
            
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
              <h4 className="font-semibold text-blue-900 mb-2 text-sm">Response Format:</h4>
              <code className="text-xs text-blue-800">{`{
  "key": "16-char-alphanumeric",
  "expire_time": 1234567890,
  "status": "valid"
}`}</code>
            </div>
          </div>
        </Card>

        {/* Verification Demo */}
        <Card className="bg-white rounded-lg shadow-md p-6 mb-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">
            <i className="fas fa-shield-alt mr-2 text-primary"></i>
            Key Verification
          </h3>
          
          <p className="text-gray-600 text-sm mb-4">Test key verification with the endpoint below:</p>
          
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Test Key</label>
              <div className="flex">
                <Input 
                  type="text" 
                  placeholder="Enter key to verify..." 
                  value={testKey}
                  onChange={(e) => setTestKey(e.target.value)}
                  className="flex-1 rounded-r-none"
                />
                <Button 
                  onClick={verifyKey}
                  className="px-4 py-2 bg-primary text-white rounded-l-none hover:bg-blue-800 transition-colors"
                >
                  <i className="fas fa-search"></i>
                </Button>
              </div>
            </div>

            {verifyResult && (
              <div className={`p-3 rounded-lg border ${
                verifyResult.status === "valid" 
                  ? "bg-green-50 border-green-200 text-green-800"
                  : verifyResult.status === "expired"
                  ? "bg-yellow-50 border-yellow-200 text-yellow-800" 
                  : "bg-red-50 border-red-200 text-red-800"
              }`}>
                <div className="flex items-center mb-1">
                  <i className={`mr-2 ${
                    verifyResult.status === "valid" 
                      ? "fas fa-check-circle"
                      : verifyResult.status === "expired"
                      ? "fas fa-exclamation-triangle"
                      : "fas fa-times-circle"
                  }`}></i>
                  <span className="font-medium">
                    {verifyResult.status === "valid" ? "Valid Key" 
                     : verifyResult.status === "expired" ? "Expired Key"
                     : "Invalid Key"}
                  </span>
                </div>
                <code className="text-xs">
                  {JSON.stringify(verifyResult)}
                </code>
              </div>
            )}

            <div className="space-y-2">
              <div className="text-xs text-gray-500">Response Examples:</div>
              
              <div className="bg-green-50 border border-green-200 rounded-lg p-3">
                <div className="flex items-center text-green-800 mb-1">
                  <i className="fas fa-check-circle mr-2"></i>
                  <span className="font-medium">Valid Key</span>
                </div>
                <code className="text-xs text-green-700">{`{"status": "valid", "message": "Key valid"}`}</code>
              </div>
              
              <div className="bg-red-50 border border-red-200 rounded-lg p-3">
                <div className="flex items-center text-red-800 mb-1">
                  <i className="fas fa-times-circle mr-2"></i>
                  <span className="font-medium">Invalid Key</span>
                </div>
                <code className="text-xs text-red-700">{`{"status": "invalid", "message": "Invalid key"}`}</code>
              </div>
              
              <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3">
                <div className="flex items-center text-yellow-800 mb-1">
                  <i className="fas fa-exclamation-triangle mr-2"></i>
                  <span className="font-medium">Expired Key</span>
                </div>
                <code className="text-xs text-yellow-700">{`{"status": "expired", "message": "Key expired", "redirect": "..."}`}</code>
              </div>
            </div>
          </div>
        </Card>

        {/* Footer */}
        <div className="text-center text-gray-500 text-sm">
          <p className="mb-2">
            <i className="fas fa-lock mr-1"></i>
            Secure 24-hour key system
          </p>
          <p className="text-xs">Keys automatically expire after 24 hours for security</p>
        </div>
      </div>
    </div>
  );
}
